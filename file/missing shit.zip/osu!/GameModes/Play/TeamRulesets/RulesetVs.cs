﻿using System;
using System.Collections.Generic;
using System.Text;

namespace osu.GameModes.Play.TeamRulesets
{
    internal class RulesetVs : RulesetBase
    {
        public RulesetVs(PlayerVs player)
            : base(player)
        {
        }

        internal override bool ContinuousPlay { get { return true; } }
    }
}
