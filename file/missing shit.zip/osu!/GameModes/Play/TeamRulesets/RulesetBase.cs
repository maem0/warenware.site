﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using osu.GameModes.Play.Components;
using osu.GameplayElements.Scoring;
using osu.Graphics.Notifications;
using osu.Online;
using osu.Online.Drawable;
using osu_common;
using osu_common.Bancho.Objects;
using osu.GameModes.Play.Rulesets.Taiko;

namespace osu.GameModes.Play.TeamRulesets
{
    internal abstract class RulesetBase : IDisposable
    {
        protected readonly PlayerVs player;

        internal RulesetBase(PlayerVs player)
        {
            this.player = player;
        }

        internal virtual Score visibleScore
        {
            get { return Player.currentScore; }
        }

        internal virtual bool ContinuousPlay
        {
            get { return true; }
        }

        internal virtual bool CheckAllNotesHit
        {
            get { return true; }
        }

        public virtual void Dispose()
        {
        }

        internal virtual void Initialize()
        {
            InitializeHitObjectPostProcessing();
        }

        internal virtual void InitializeHitObjectPostProcessing()
        {
            
        }

        internal virtual void Update()
        {
           
        }

        internal virtual Scoreboard CreateScoreboard()
        {
            switch (Player.Mode)
            {
                case PlayModes.Taiko:
                    return new Scoreboard(6, null, new Vector2(0, RulesetTaiko.TAIKO_BAR_HEIGHT + 130), true);
                default:
                    return new Scoreboard(PlayerVs.Match.slotUsedCount, null, new Vector2(0, 150), true);
            }
            
        }

        internal virtual void HandleFrame(bScoreFrame frame)
        {
            ScoreboardEntry match = player.scoreEntries[frame.id];
            
            if (match == null) return;
            
            match.HandleUpdate(frame);
            PlayerVs.scoreboardUpdatePending = true;
        }

        internal virtual void PopulateScoreboard()
        {
            Player.ScoreBoard.inputCount = PlayerVs.Match.slotUsedCount;
            
            for (int i = 0; i < bMatch.slotCount; i++)
            {
                //todo: WTF AT THIS

                if (PlayerVs.Match.slotStatus[i] != SlotStatus.Playing)
                {
                    player.scoreEntries.Add(null);
                    continue;
                }

                /*User u = BanchoClient.GetUserById(PlayerVs.Match.slotId[i]);
                
                if (u == null)
                {
                    //todo: dump some debug info here
                    /*
                        System.ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument argument,
                                          ExceptionResource resource)M
                        09:18 <BanchoBot>    at System.ThrowHelper.ThrowArgumentOutOfRangeException()M
                        09:18 <BanchoBot>    at osu.GameModes.Play.TeamRulesets.TeamRuleset.PopulateScoreboard()M
                        09:18 <BanchoBot>    at osu.GameModes.Play.PlayerVs.InitializeScoreboard()M
                        09:18 <BanchoBot>    at osu.GameModes.Play.Player.Initialize()M
                        09:18 <BanchoBot>    at osu.GameModes.Play.PlayerVs.Initialize()M
                        09:18 <BanchoBot>    at Microsoft.Xna.Framework.Game.GameComponentAdded(Object
                                          sender, GameComponentCollectionEventArgs e)M
                        09:18 <BanchoBot>    at
                        Microsoft.Xna.Framework.GameComponentCollection.OnComponentAdded(GameComponentCollectionEventArgs eventArgs)M
                        09:18 <BanchoBot>    at
                        Microsoft.Xna.Framework.GameComponentCollection.InsertItem(Int32 index,
                                          IGameComponent item)M
                     
                    player.scoreEntries.Add(null);
                    continue;
                }*/

                ScoreboardEntry se = new ScoreboardEntryExtended(i, PlayerVs.Match.UserSlots[i], PlayerVs.Match.matchScoringType, Player.Mode, PlayerVs.Match.slotTeam[i]);

                se.spriteBackground.StartColour = new Color(0, 0, 0, 180);
                
                player.scoreEntries.Add(se);

                Player.ScoreBoard.Add(se);
            }

            player.scoreEntry = player.scoreEntries[player.localPlayerMatchId];

            if (player.scoreEntry != null)
                Player.ScoreBoard.SetTrackingEntry(player.scoreEntry);

            Player.ScoreBoard.Reorder(false);
        }

        internal virtual void OnFail()
        {
        }

        internal virtual void OnCompletion()
        {
            player.multiplayerRankingText.FadeOut(100);
        }

        internal virtual void HandlePlayerFailed(int i)
        {
            if (player.scoreEntries == null || player.scoreEntries[i] == null) return;
            player.scoreEntries[i].spriteRank.Text = "Failed";
            player.scoreEntries[i].Passing = false;
        }

        internal virtual void LoadRanking()
        {
            GameBase.ChangeMode(OsuModes.RankingVs);
            NotificationManager.ClearMessageMassive(null, null);
        }

        internal virtual void UpdateRankingText()
        {
            if (PlayerVs.TeamMode)
                return;

            if (player.scoreEntry.Passing)
            {
                string ext;
                switch (player.scoreEntry.rank)
                {
                    case 1:
                        ext = "st";
                        break;
                    case 2:
                        ext = "nd";
                        break;
                    case 3:
                        ext = "rd";
                        break;
                    default:
                        ext = "th";
                        break;
                }
                player.multiplayerRankingText.Text = player.scoreEntry.rank + ext;
            }
            else
                player.multiplayerRankingText.Text = "Failed";
        }

        internal virtual void HandlePlayerLeft(int i)
        {
            if (player.scoreEntries == null || player.scoreEntries[i] == null)
                return;

            player.scoreEntries[i].spriteRank.Text = "Quit";
            player.scoreEntries[i].Passing = false;
        }
    }
}
