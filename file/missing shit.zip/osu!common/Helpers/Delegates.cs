﻿using System;
using System.Collections.Generic;
using System.Text;

namespace osu_common.Helpers
{
    public delegate void VoidDelegate();
    public delegate void BoolDelegate(bool b);
}
