//
//  TimingPoint.m
//  Osu
//
//  Created by Christopher Luu on 8/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "TimingPoint.h"


@implementation TimingPoint

@synthesize offsetMs;
@synthesize beatLength;
@synthesize sampleSetId;
@synthesize useCustomSamples;
@synthesize sampleVolume;

@end
