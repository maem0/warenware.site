//
//  AnimationSystem.h
//  Osu
//
//  Created by Christopher Luu on 9/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Texture2D.h"

typedef enum
{
	kAnimationType_Scale = 1,
	kAnimationType_Fade = 2,
	kAnimationType_Move = 4,
	kAnimationType_VectorScale = 8,
	kAnimationType_Rotate = 16,
	kAnimationType_Colour = 32,
	kAnimationType_Loop = 64,
} eAnimationType;

@interface AnimationSystem : NSObject
{
@private
	NSMutableSet *_animationSet;
}

- (void) drawAnimations:(double)curTime;
- (void) addItem:(eAnimationType)inType texture:(Texture2D*)inTexture startTime:(double)inStartTime endTime:(double)inEndTime layer:(int)inLayer easing:(int)inEasing startPos:(CGPoint)inStartPos startScale:(float)startScale ,...;

@end
