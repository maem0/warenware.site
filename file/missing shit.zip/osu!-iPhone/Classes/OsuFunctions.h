//
//  OsuFunctions.h
//  Osu
//
//  Created by Christopher Luu on 8/30/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define SCREEN_SIZE_X 720
#define SCREEN_SIZE_Y 480

#define GAME_STAGE_X 96.0f
#define GAME_STAGE_Y 64.0f

#define TOP_BAR_HEIGHT 44.375f
#define SCORE_HEIGHT 28.0f

#define FADE_TIME 500.0f // ms to fade away

#define PI 3.141592653585

typedef struct _colorStruct
{
	int r, g, b;
} tColor;

@interface OsuFunctions : NSObject
{

}

+ (float) dist:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2;
+ (float) mapDifficultyRange:(float)difficulty min:(float)min mid:(float)mid max:(float)max;

@end
