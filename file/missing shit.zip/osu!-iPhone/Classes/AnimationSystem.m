//
//  AnimationSystem.m
//  Osu
//
//  Created by Christopher Luu on 9/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AnimationSystem.h"
#import "OsuFunctions.h"

@interface AnimatedItem : NSObject
{
@private
	eAnimationType type;
	Texture2D *texture;
	double startTime;
	double endTime;
	int layer;
	int easing;
	CGPoint startPos;
	float startScale;

	// params
	float endScale;
	tColor startColor;
	tColor endColor;
	float startOpacity;
	float endOpacity;
}

@property eAnimationType type;
@property(assign) Texture2D *texture;
@property double startTime;
@property double endTime;
@property int layer;
@property int easing;
@property CGPoint startPos;
@property float startScale;
@property float endScale;
@property float startOpacity;
@property float endOpacity;
@property tColor startColor;
@property tColor endColor;

@end

@implementation AnimatedItem

@synthesize type;
@synthesize texture;
@synthesize startTime;
@synthesize endTime;
@synthesize layer;
@synthesize easing;
@synthesize startPos;
@synthesize startScale;
@synthesize endScale;
@synthesize startColor;
@synthesize endColor;
@synthesize startOpacity;
@synthesize endOpacity;
@synthesize startColor;
@synthesize endColor;

@end

@implementation AnimationSystem

- (id) init
{
	if (self = [super init])
	{
		_animationSet = [[NSMutableSet alloc] init];
		return self;
	}
	return NULL;
}

- (void)dealloc
{
	[_animationSet release];
	[super dealloc];
}

- (void) addItem:(eAnimationType)inType texture:(Texture2D*)inTexture startTime:(double)inStartTime endTime:(double)inEndTime layer:(int)inLayer easing:(int)inEasing startPos:(CGPoint)inStartPos startScale:(float)inStartScale,...
{
	AnimatedItem *newItem = [[AnimatedItem alloc] init];
	newItem.type = inType;
	newItem.texture = inTexture;
	newItem.startTime = inStartTime;
	newItem.endTime = inEndTime;
	newItem.layer = inLayer;
	newItem.easing = inEasing;
	newItem.startPos = inStartPos;
	newItem.startScale = inStartScale;

	va_list argumentList;
	double tmpFloat;
	va_start(argumentList, inStartScale);
	if (inType & kAnimationType_Scale)
	{
		tmpFloat = va_arg(argumentList, double);
		newItem.endScale = tmpFloat;
	}
	if (inType & kAnimationType_Fade)
	{
		tmpFloat = va_arg(argumentList, double);
		newItem.startOpacity = tmpFloat;
		tmpFloat = va_arg(argumentList, double);
		newItem.endOpacity = tmpFloat;
	}
	va_end(argumentList);

	@synchronized(_animationSet)
	{
		[_animationSet addObject:newItem];
	}
}

- (void) drawAnimations:(double)curTime
{
	AnimatedItem *tmp;
	NSMutableSet *toRemove = [[NSMutableSet alloc] init];
	float iter;

	@synchronized(_animationSet)
	{
		for (tmp in _animationSet)
		{
			if (curTime < tmp.startTime)
				continue;
			if (curTime >= tmp.endTime)
			{
				[toRemove addObject:tmp];
				continue;
			}

			iter = (curTime - tmp.startTime) / (tmp.endTime - tmp.startTime);

			glPushMatrix();
			glTranslatef(tmp.startPos.x, tmp.startPos.y, 0.0f);
			if (tmp.type & kAnimationType_Scale)
				glScalef(tmp.startScale + (tmp.endScale - tmp.startScale) * iter, -(tmp.startScale + (tmp.endScale - tmp.startScale) )* iter, 1.0f);
			else
				glScalef(tmp.startScale, -tmp.startScale, 1.0f);

			if (tmp.type & kAnimationType_Fade)
				glColor4f(1.0f, 1.0f, 1.0f, tmp.startOpacity + (tmp.endOpacity - tmp.startOpacity) * iter);
			[tmp.texture drawAtPoint:CGPointMake(0, 0)];
			glPopMatrix();
		}
		[_animationSet minusSet:toRemove];
	}
}

@end
