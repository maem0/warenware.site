//
//  OsuPlayer.h
//  Osu
//
//  Created by Christopher Luu on 8/28/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface OsuPlayer : NSObject {
@private
	NSString *name;
	int score;
	int health;
}

@property(assign) NSString *name;
@property int score;
@property int health;

@end
