//
//  OsuFunctions.m
//  Osu
//
//  Created by Christopher Luu on 8/30/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "OsuFunctions.h"


@implementation OsuFunctions

+ (float) dist:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2
{
	return sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
}

+ (float) mapDifficultyRange:(float)difficulty min:(float)min mid:(float)mid max:(float)max
{
    if (difficulty > 5.0f)
		return mid + (max - mid)*(difficulty - 5.0f)/5.0f;
    if (difficulty < 5.0f)
		return mid - (mid - min)*(5.0f - difficulty)/5.0f;
    return mid;
}

@end
