//
//  OsuPlayer.m
//  Osu
//
//  Created by Christopher Luu on 8/28/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "OsuPlayer.h"


@implementation OsuPlayer

@synthesize name;
@synthesize score;
@synthesize health;

@end
